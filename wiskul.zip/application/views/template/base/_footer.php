<footer class="main-footer">
    <strong>Copyright &copy; <script>
            document.write(new Date().getFullYear())
        </script> <a href="<?= base_url(); ?>">Wisata Kuliner Garut</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.1 Patch A
    </div>
</footer>