    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?= base_url(); ?>assets/vege/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vege/css/animate.css">
    
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vege/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vege/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vege/css/magnific-popup.css">

    <link rel="stylesheet" href="<?= base_url(); ?>assets/vege/css/aos.css">

    <link rel="stylesheet" href="<?= base_url(); ?>assets/vege/css/ionicons.min.css">

    <link rel="stylesheet" href="<?= base_url(); ?>assets/vege/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vege/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vege/css/flaticon.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vege/css/icomoon.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vege/css/style.css">