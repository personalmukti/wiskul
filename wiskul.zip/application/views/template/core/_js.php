<script src="<?= base_url(); ?>assets/vege/js/jquery.min.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/popper.min.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/bootstrap.min.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/jquery.easing.1.3.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/jquery.waypoints.min.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/jquery.stellar.min.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/owl.carousel.min.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/jquery.magnific-popup.min.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/aos.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/jquery.animateNumber.min.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/bootstrap-datepicker.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="<?= base_url(); ?>assets/vege/js/google-map.js"></script>
  <script src="<?= base_url(); ?>assets/vege/js/main.js"></script>